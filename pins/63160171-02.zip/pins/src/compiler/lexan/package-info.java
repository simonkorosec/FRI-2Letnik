/**
 * Leksikalni analizator.
 * 
 * @author sliva
 */
package compiler.lexan;