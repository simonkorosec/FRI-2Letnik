/**
 * Sintaksni analizator.
 * 
 * @author sliva
 */
package compiler.synan;