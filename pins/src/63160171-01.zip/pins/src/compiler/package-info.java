/**
 * Prevajalnik za programski jezik PREV.
 * <p>
 * Celotna izvorna koda prevajalnika za programski jezik PINS je zbrana v paketu {@link compiler} in njegovih podpaketih.
 * 
 * @author sliva
 */
package compiler;