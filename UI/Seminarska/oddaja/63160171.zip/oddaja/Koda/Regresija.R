pod<- read.table(file="podatkiSem1.txt", sep=",", header=TRUE)
sel <- sample(1:nrow(pod), size=as.integer(nrow(pod)*0.7), replace=F)

learn <- pod[sel,]
test <- pod[-sel,]

 lm.model <- lm(PM10 ~ .,data=learn)
 lm.model

predicted<-predict(lm.model,test)

observed<-test$PM10

mae <- function(observed, predicted)
 {
 	mean(abs(observed - predicted))
 }
 
 rmae <- function(observed, predicted, mean.val) 
 {  
 	sum(abs(observed - predicted)) / sum(abs(observed - mean.val))
 }
 
 mse <- function(observed, predicted)
 {
 	mean((observed - predicted)^2)
 }
 
 rmse <- function(observed, predicted, mean.val) 
 {  
 	sum((observed - predicted)^2)/sum((observed - mean.val)^2)
 }

mae(observed,predicted)
# 7.961599
 
 rmae(observed,predicted,mean(learn$PM10))
# 0.831104

library(rpart)
 rt.model<-rpart(PM10 ~ .,learn)
 predicted <- predict(rt.model, test)


rt <- rpart(PM10 ~ ., learn, minsplit = 100,cp=0)
 
 plot(rt);text(rt, pretty = 0)
 
 rt.model2 <- prune(rt.model, cp = 0.02)
 
 plot(rt.model2)
 predicted <- predict(rt.model2, test)
 
 rmae(observed, predicted, mean(learn$PM10))
# 0.8366395



lm.model <- lm(O3 ~ .,data=learn)
lm.model

predicted<-predict(lm.model,test)
 
observed<-(test$O3)

mae(observed,predicted)
# 14.3719
  
rmae(observed,predicted,mean(learn$O3))
#0.5029431

 library(CORElearn)

#Formula 2 za O3
 
ff<-as.formula("O3 ~ Temperatura_lokacija_max + Glob_sevanje_mean + Temperatura_Krvavec_mean + Pritisk_mean + Hitrost_vetra_max + Glob_sevanje_max + Temperatura_Krvavec_min + Padavine_sum")


#Formula 3 za O3
fx<-as.formula(O3 ~ Glob_sevanje_mean + Glob_sevanje_max +  Temperatura_lokacija_mean + Temperatura_Krvavec_max + Vlaga_min + PM10 + Vlaga_max)


#Formula 2 za PM10
tt<-as.formula(“PM10 ~ Temperatura_lokacija_min + Sunki_vetra_max + Padavine_mean + Postaja + Temperatura_Krvavec_min + O3 + Sunki_vetra_mean + Temperatura_lokacija_mean “)


#Formula 3 za PM10
tx<-as.formula(“PM10 ~ Temperatura_lokacija_max + Temperatura_lokacija_mean + O3 + Temperatura_Krvavec_mean + Pritisk_max + Pritisk_mean + Glob_sevanje_max  + Vlaga_min + Glob_sevanje_mean”)


 rt.core <- CoreModel(ff, data=learn, model="regTree", modelTypeReg = 1)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$O3))
#0.5583526

  rt.core <- CoreModel(ff, data=learn, model="regTree", modelTypeReg = 2)
  predicted <- predict(rt.core, test)
  rmae(observed, predicted, mean(learn$O3))
# 0.5420835

  rt.core <- CoreModel(ff, data=learn, model="regTree", modelTypeReg = 3)
  predicted <- predict(rt.core, test)
  rmae(observed, predicted, mean(learn$O3))
# 0.5180777

  
  
    rt.core <- CoreModel(ff, data=learn, model="regTree", modelTypeReg = 4)
  predicted <- predict(rt.core, test)
  rmae(observed, predicted, mean(learn$O3))
# 0.5294955
 
  
  rt.core <- CoreModel(ff, data=learn, model="regTree", modelTypeReg = 5)
  predicted <- predict(rt.core, test)
  rmae(observed, predicted, mean(learn$O3))
#0.5098632
 
  
  rt.core <- CoreModel(ff, data=learn, model="regTree", modelTypeReg = 6)
  predicted <- predict(rt.core, test)
  rmae(observed, predicted, mean(learn$O3))
#0.4774612
 
  
  rt.core <- CoreModel(ff, data=learn, model="regTree", modelTypeReg = 7)
  predicted <- predict(rt.core, test)
  rmae(observed, predicted, mean(learn$O3))
#0.4850018
 
  
   rt.core <- CoreModel(ff , data=learn, model="regTree", modelTypeReg = 8)
  predicted <- predict(rt.core, test)
  rmae(observed, predicted, mean(learn$O3))
#1.140306
  

 rt.core <- CoreModel(fx, data=learn, model="regTree", modelTypeReg = 1)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$O3))
# 0.5556219

   rt.core <- CoreModel(fx, data=learn, model="regTree", modelTypeReg = 2)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$O3))
#0.5461032
 
  rt.core <- CoreModel(fx, data=learn, model="regTree", modelTypeReg = 3)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$O3))
#0.4979781
 
  rt.core <- CoreModel(fx, data=learn, model="regTree", modelTypeReg = 4)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$O3))
#0.503557
 
  rt.core <- CoreModel(fx, data=learn, model="regTree", modelTypeReg = 5)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$O3))
# 0.5006464

  rt.core <- CoreModel(fx, data=learn, model="regTree", modelTypeReg = 6)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$O3))
#0.4776968
 
  rt.core <- CoreModel(fx, data=learn, model="regTree", modelTypeReg = 7)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$O3))
# 0.4774028

 
  rt.core <- CoreModel(O3 ~ Glob_sevanje_mean + Glob_sevanje_max + Temperatura_lokacija_mean + Temperatura_Krvavec_max + Vlaga_min + PM10 + Vlaga_max, data=learn, model="regTree", modelTypeReg = 8)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$O3))
#0.830242



rt.core <- CoreModel(O3 ~ ., data=learn, model="regTree", modelTypeReg = 1)
predicted <- predict(rt.core, test)
rmae(observed, predicted, mean(learn$O3))
#0.5352372


rt.core <- CoreModel(O3 ~ ., data=learn, model="regTree", modelTypeReg = 2)
predicted <- predict(rt.core, test)
rmae(observed, predicted, mean(learn$O3))
#0.5289665

rt.core <- CoreModel(O3 ~ ., data=learn, model="regTree", modelTypeReg = 3)
predicted <- predict(rt.core, test)
rmae(observed, predicted, mean(learn$O3))
#0.5466939


rt.core <- CoreModel(O3 ~ ., data=learn, model="regTree", modelTypeReg = 4)
predicted <- predict(rt.core, test)
rmae(observed, predicted, mean(learn$O3))
#0.523285


rt.core <- CoreModel(O3 ~ ., data=learn, model="regTree", modelTypeReg = 5)
predicted <- predict(rt.core, test)
rmae(observed, predicted, mean(learn$O3))
#0.4728432


rt.core <- CoreModel(O3 ~ ., data=learn, model="regTree", modelTypeReg = 6)
predicted <- predict(rt.core, test)
rmae(observed, predicted, mean(learn$O3))
#0.4600129


rt.core <- CoreModel(O3 ~ ., data=learn, model="regTree", modelTypeReg = 7)
predicted <- predict(rt.core, test)
rmae(observed, predicted, mean(learn$O3))
#0.4863083


rt.core <- CoreModel(O3 ~ ., data=learn, model="regTree", modelTypeReg = 8)
predicted <- predict(rt.core, test)
rmae(observed, predicted, mean(learn$O3))
# 0.6953557


#————————————
#ZA PM10


 rt.core <- CoreModel(PM10 ~ ., data=learn, model="regTree", modelTypeReg = 1)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.7899559

rt.core <- CoreModel(PM10 ~ ., data=learn, model="regTree", modelTypeReg = 2)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.8099541

rt.core <- CoreModel(PM10 ~ ., data=learn, model="regTree", modelTypeReg = 3)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.8090228

rt.core <- CoreModel(PM10 ~ ., data=learn, model="regTree", modelTypeReg = 4)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.863832

rt.core <- CoreModel(PM10 ~ ., data=learn, model="regTree", modelTypeReg = 5)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.7479881

rt.core <- CoreModel(PM10 ~ ., data=learn, model="regTree", modelTypeReg = 6)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.6894159

rt.core <- CoreModel(PM10 ~ ., data=learn, model="regTree", modelTypeReg = 7)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.7433226

rt.core <- CoreModel(PM10 ~ ., data=learn, model="regTree", modelTypeReg = 8)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#1.127945




rt.core <- CoreModel(tt, data=learn, model="regTree", modelTypeReg = 1)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.8174941


rt.core <- CoreModel(tt, data=learn, model="regTree", modelTypeReg = 2)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.7822657

rt.core <- CoreModel(tt, model="regTree", modelTypeReg = 3)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.8184151

rt.core <- CoreModel(tt, data=learn, model="regTree", modelTypeReg = 4)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.8153686

rt.core <- CoreModel(tt, data=learn, model="regTree", modelTypeReg = 5)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.7633269

rt.core <- CoreModel(tt, data=learn, model="regTree", modelTypeReg = 6)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.7169512

rt.core <- CoreModel(tt, data=learn, model="regTree", modelTypeReg = 7)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.7405943

rt.core <- CoreModel(tt, data=learn, model="regTree", modelTypeReg = 8)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#1.248134



rt.core <- CoreModel(tx, data=learn, model="regTree", modelTypeReg = 1)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.7785541


rt.core <- CoreModel(tx, data=learn, model="regTree", modelTypeReg = 2)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.7821141

rt.core <- CoreModel(tx, data=learn, model="regTree", modelTypeReg = 3)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.7656336

rt.core <- CoreModel(tx, data=learn, model="regTree", modelTypeReg = 4)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.7753401

rt.core <- CoreModel(tx, data=learn, model="regTree", modelTypeReg = 5)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.7422536

rt.core <- CoreModel(tx, data=learn, model="regTree", modelTypeReg = 6)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.7033621

rt.core <- CoreModel(tx, data=learn, model="regTree", modelTypeReg = 7)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#0.7229701

rt.core <- CoreModel(tx, data=learn, model="regTree", modelTypeReg = 8)
 predicted <- predict(rt.core, test)
 rmae(observed, predicted, mean(learn$PM10))
#2.314778

#
#Nevronske
#



nn.model <- nnet(tt, learn, size = 2, decay = 0.01, maxit = 100, linout = T, MaxNWts=4000)
predicted <- predict(nn.model, test)
rmae(observed, predicted, mean(learn$PM10))
#0.8979192


nn.model <- nnet(PM10~ ., learn, size = 5, decay = 0.01, maxit = 100, linout = T, MaxNWts=6700)
predicted <- predict(nn.model, test)
rmae(observed, predicted, mean(learn$PM10))
#0.8609758


nn.model <- nnet(O3~ ., learn, size = 5, decay = 0.01, maxit = 100, linout = T, MaxNWts=6700)
predicted <- predict(nn.model, test)
rmae(observed, predicted, mean(learn$O3))
#0.6986606


nn.model <- nnet(ff, learn, size = 2, decay = 0.01, maxit = 1000, linout = T, MaxNWts=52)
predicted <- predict(nn.model, test)
rmae(observed, predicted, mean(learn$O3))
#0.9999996

#———————————————————
#Rergresijska drevesa
#

ff<-as.formula("O3 ~ Temperatura_lokacija_max + Glob_sevanje_mean + Temperatura_Krvavec_mean + Pritisk_mean + Hitrost_vetra_max + Glob_sevanje_max + Temperatura_Krvavec_min + Padavine_sum")

rt <- rpart(O3 ~ ., learn, minsplit = 100)
predicted <- predict(rt, test)
rmae(observed, predicted, mean(learn$O3))
#0.6622979

rt <- rpart(ff, learn, minsplit = 600)
predicted <- predict(rt, test)
rmae(observed, predicted, mean(learn$O3))
#0.6115082



rt <- rpart(fx, learn, minsplit = 600)
predicted <- predict(rt, test)
rmae(observed, predicted, mean(learn$O3))
#[1] 0.6149047



rt <- rpart(PM10 ~ ., learn, minsplit = 100)
predicted <- predict(rt, test)
rmae(observed, predicted, mean(learn$PM10))
# 0.8274773

 rt <- rpart(tt , learn, minsplit = 100)
predicted <- predict(rt, test)
rmae(observed, predicted, mean(learn$PM10))
#0.7975253



rt <- rpart(tx , learn, minsplit = 100)
predicted <- predict(rt, test)
rmae(observed, predicted, mean(learn$PM10))
#0.8278224





