Nastavitev aliasov:
alias bus='python bus.py'
alias route='python route.py'

Primer uporabe:
bus arrivals to Živalski vrt line 18 at 10:00
bus departures from Kolodvor line 18
route to Ko
